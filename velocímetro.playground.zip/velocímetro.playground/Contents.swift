//: Playground - noun: a place where people can play

import UIKit

enum velocidades : Int{
    case apagado = 0
    case velocidadBaja = 20
    case velocidadMedia = 50
    case velocidadAlta = 120
    
    init(velocidadInicial : velocidades) {
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : velocidades
    var actual = 0
    var velocidadEnCadena = "apagado"
    var arranque = true

    
    init() {
        self.velocidad = velocidades.apagado
    }
    
    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena : String) {
        
        if arranque == true {
            arranque = false
             return (actual, velocidadEnCadena)
        }
   
        
            switch velocidad{
            case .apagado:
                velocidad = velocidades.velocidadBaja
                actual = velocidad.rawValue
                velocidadEnCadena = "velocidadBaja"
                return (actual, velocidadEnCadena)
            case .velocidadBaja:
                velocidad = velocidades.velocidadMedia
                actual = velocidad.rawValue
                velocidadEnCadena = "velocidadMedia"
                return (actual, velocidadEnCadena)
            case .velocidadMedia:
                velocidad = velocidades.velocidadAlta
                actual = velocidad.rawValue
                velocidadEnCadena = "velocidadAlta"
                return (actual, velocidadEnCadena)
            case .velocidadAlta:
                velocidad = velocidades.velocidadMedia
                actual = velocidad.rawValue
                velocidadEnCadena = "velocidadMedia"
                return (actual, velocidadEnCadena)
            default : velocidades.apagado
                 return (actual, velocidadEnCadena)
            }
        
       
        
    }
}

var auto = Auto()

let numeros = 0...20

for i in numeros{
    print(i)
    print(auto.cambioDeVelocidad())
}




